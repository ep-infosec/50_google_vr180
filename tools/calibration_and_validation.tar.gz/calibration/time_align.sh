#!/bin/bash
#
# Factory script for VR180 for time alignment.
#
# Usage: time_align.sh datadir --focal_length_in_pixels=focal_length [--pixel_aspect_ratio=1.0]

set -o errexit
set -o nounset

# The calibration binaries are in the same folder as the script, unless
# VR180_BIN is specified.
SCRIPTPATH=$(dirname "$(readlink -f "$0")")
VR180_BIN=${VR180_BIN:-$SCRIPTPATH}
CALIBRATE_VR180_CLI="${calibrate_vr180_cli:-${VR180_BIN}/calibrate_vr180_cli}"

TARGET="${TARGET:-big100}"
VERBOSE_CALIBRATION_LOGGING="${VERBOSE_CALIBRATION_LOGGING:-true}"
NUM_DETECTOR_THREADS=${NUM_DETECTOR_THREADS:-4}

if [[ $# -lt 1 ]]; then
  echo "usage: $0 datadir --focal_length_in_pixels=focal_length [--pixel_aspect_ratio=1.0]"
  exit 1
fi

CALDIR="$1"
shift

if [[ ! -d "${CALDIR}" ]]; then
  echo "$0: ${CALDIR} does not exist"
  exit 1
fi

MODEL="${CALDIR}/model_1.rio"
OUT_LOG="${CALDIR}/cal_log.txt"
OUT_CALIBRATION="${CALDIR}/calibration.txt"

rm -f "${OUT_LOG}" 2>/dev/null || :;
rm -f "${OUT_CALIBRATION}" 2>/dev/null || :;
rm -f "${MODEL}" 2>/dev/null || :;

"${CALIBRATE_VR180_CLI}" \
  --logtostderr \
  -in_pattern_yaml "${TARGET}" \
  -in_dataset "${CALDIR}" \
  -out_calibration "${OUT_CALIBRATION}" \
  -verbose="${VERBOSE_CALIBRATION_LOGGING}" \
  -num_detector_threads="${NUM_DETECTOR_THREADS}" \
  "$@" \
  2>&1 | tee "${OUT_LOG}"

# It is normal for IMU extrinsics to fail on the rocker.

camera_calibration_passed=$(grep -c "^camera_calibration_pass: true$" "${OUT_CALIBRATION}")
time_alignment_passed=$(grep -c "^time_alignment_pass: true$" "${OUT_CALIBRATION}")

if [[ ${camera_calibration_passed} -ne 1 ]]; then
  echo "$0: Camera calibration failed"
  exit 1
fi

if [[ ${time_alignment_passed} -ne 1 ]]; then
  echo "$0: Time alignment failed"
  exit 1
fi

echo
echo
echo "********"
echo "********"
echo "********"
echo
grep -h  "^estimated_time_offset" "${OUT_CALIBRATION}"

exit 0

