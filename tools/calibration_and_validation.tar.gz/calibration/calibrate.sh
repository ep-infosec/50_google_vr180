#!/bin/bash
#
# Factory script for VR180 to run a full calibration from a
# calibration recording dataset.
#
# Usage: calibrate.sh datadir --focal_length_in_pixels=focal_length [--pixel_aspect_ratio=1.0]

set -o errexit
set -o nounset

# The calibration binaries are in the same folder as the script, unless
# VR180_BIN is specified.
SCRIPTPATH=$(dirname "$(readlink -f "$0")")
VR180_BIN=${VR180_BIN:-$SCRIPTPATH}

CALIBRATE_VR180_CLI="${CALIBRATE_VR180_CLI:-${VR180_BIN}/calibrate_vr180_cli}"
CREATE_MP4_BOXES_CLI="${CREATE_MP4_BOXES_CLI:-${VR180_BIN}/create_mp4_boxes_cli}"

TARGET="${TARGET:-big100}"
VERBOSE_CALIBRATION_LOGGING="${VERBOSE_CALIBRATION_LOGGING:-true}"
NUM_DETECTOR_THREADS="${NUM_DETECTOR_THREADS:-4}"

if [[ $# -lt 1 ]]; then
  echo "usage: $0 datadir --focal_length_in_pixels=focal_length [--pixel_aspect_ratio=1.0]"
  exit 1
fi


CALDIR="$1"
shift

if [[ ! -d "${CALDIR}" ]]; then
  echo "$0: ${CALDIR} does not exist"
  exit 1
fi

MODEL="${CALDIR}/model_1.rio"
OUT_LOG="${CALDIR}/cal_log.txt"
OUT_CALIBRATION="${CALDIR}/calibration.txt"
OUT_BOX_BASE="${CALDIR}/mp4_box"

rm -f "${OUT_LOG}" 2>/dev/null
rm -f "${OUT_CALIBRATION}" 2>/dev/null
rm -f "${OUT_BOX_BASE}"* 2>/dev/null


"${CALIBRATE_VR180_CLI}" \
  --logtostderr \
  -in_pattern_yaml "${TARGET}" \
  -in_dataset "${CALDIR}" \
  -out_calibration "${OUT_CALIBRATION}" \
  -verbose="${VERBOSE_CALIBRATION_LOGGING}"\
  -num_detector_threads="${NUM_DETECTOR_THREADS}" \
  "$@" \
  2>&1 | tee "${OUT_LOG}"
calibration_exit_code=${PIPESTATUS[0]}

if [[ ! -r "${MODEL}" ]]; then
  echo "$0: Could not find ${MODEL} (probably because calibration failed)."
  exit 1
fi

"${CREATE_MP4_BOXES_CLI}" \
  --logtostderr \
  -in_model "${MODEL}" \
  -out_box_base "${OUT_BOX_BASE}" \
  2>&1 | tee -a "${OUT_LOG}"
create_mp4_box_exit_code=${PIPESTATUS[0]}

if [[ ${calibration_exit_code} -ne 0 ]];  then
  echo "$0: Calibration exited with code ${calibration_exit_code}"
  exit 1
fi

if [[ ${create_mp4_box_exit_code} -ne 0 ]];  then
  echo "$0: create_mp4_boxes_cli exited with code ${create_mp4_box_exit_code}"
  exit 1
fi
